from django.apps import AppConfig

class SulphurConfig(AppConfig):
    name = 'sulphur'