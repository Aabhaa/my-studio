from django.apps import AppConfig


class SadminConfig(AppConfig):
    name = 'sadmin'
