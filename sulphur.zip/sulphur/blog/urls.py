from django.urls import path
from . import views

app_name = 'blog'
urlpatterns = [
    path('posts/<int:offset>/<int:limit>/', views.posts, name='posts'),
    path('navs/', views.navs, name='navs'),
    path('foots/', views.foots, name='foots'),

    path('add_post/', views.add_new_post, name='add_post'),
    path('add_nav/', views.add_nav, name='add_nav'),
    path('add_foot/', views.add_foot, name='add_foot'),

    path('feed_new_post/', views.feed_new_post, name='feed_new_post'),
    path('feed_new_nav/', views.feed_new_nav, name='feed_new_nav'),
    path('feed_new_foot/', views.feed_new_foot, name='feed_new_foot'),

    path('<slug:cat>/<int:post_id>/<slug:post_title>', views.single_post, name='single_post'),
]