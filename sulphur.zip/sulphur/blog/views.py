from django.shortcuts import render, redirect
from sulphur.lib.fetcher import top_posts, all_navs, all_foots
from .forms import new_post_form, new_nav_form, new_foot_form
from django.utils import timezone
from sulphur.lib.authentication import is_loggedin
from django.template.defaultfilters import slugify
from .models import Post, Category
from sadmin.models import User

# Create your views here.

# ----------------- All Posts------------
#if the variable for pagination
def posts(request, offset, limit):
    if is_loggedin(request):
        record_list = top_posts(offset, limit)
        return render(request, 'blog/posts.html', {'record_list': record_list})
    else:
        msg = 'You`\re not logged in.'
        return render(request, 'debug.html', {'message': msg})
    
# It show the all nav links
def navs(request):
    if is_loggedin(request):
        nav_links = all_navs()
        return render(request, 'blog/navs.html', {'nav_links': nav_links})
    else:
        msg = 'You`\re not logged in.'
        return render(request, 'debug.html', {'message': msg})

# Show all the footer content
def foots(request):
    if is_loggedin(request):
        foot_list = all_foots()
        return render(request, 'blog/foots.html', {'foots': foot_list})
    else:
        msg = 'You`\re not logged in.'
        return render(request, 'debug.html', {'message': msg})


# ---------------- Add new post form---------
# It render the add new post form
def add_new_post(request):
    active = True
    if is_loggedin(request):
        return render(request, 'blog/new_post.html', {'active': active, 'new_post_form': new_post_form})
    else:
        active = False
        return render(request, 'blog/new_post.html', {'message': 'You can\'t add post, you are not logged in', 'active': active})

# It render the add new nav form
def add_nav(request):
    active = True
    if is_loggedin(request):
        return render(request, 'blog/new_nav.html', {'active': active, 'new_nav_form': new_nav_form})
    else:
        active = False
        return render(request, 'blog/new_nav.html', {'message': 'You can\'t add post, you are not logged in', 'active': active})

def add_foot(request):
    active = True
    if is_loggedin(request):
        return render(request, 'blog/new_foot.html', {'active': active, 'new_foot_form': new_foot_form})
    else:
        active = False
        return render(request, 'blog/new_foot.html', {'message': 'You can\'t add post, you are not logged in', 'active': active})



# --------------- Feeding into database------
# It add the new post data into database
def feed_new_post(request):

    if is_loggedin(request):
        if request.method == 'POST' or request.method == 'FILES':
            # Validating the form
            blog_post = new_post_form(request.POST)
            if blog_post.is_valid():
                #Extracting the data
                author = User.objects.get(login = request.session['username'])
                data = {
                    'title': blog_post.cleaned_data['title'],
                    'content': blog_post.cleaned_data['content'],
                    'author': author,
                    'pub_date': timezone.now(),
                    'view_count': 0,
                    'url': slugify(blog_post.cleaned_data['title']),
                    'unlisted': 0,
                    'last_modified': timezone.now(),
                    'is_page': 0,
                    'in_nav': 0,
                    'in_footer': 0,
                    'keywords' : blog_post.cleaned_data['keywords'],
                    'description' : blog_post.cleaned_data['description'],
                    'social': 0,
                    'category': Category.objects.get(pk = blog_post.cleaned_data['category']),
                }
                # Instance of the Model Post
                n_p = Post(
                    title = data['title'],
                    content = data['content'],
                    author = data['author'],
                    pub_date = data['pub_date'],
                    view_count = data['view_count'],
                    url = data['url'],
                    unlisted = data['unlisted'],
                    last_modified = data['last_modified'],
                    is_page = data['is_page'],
                    in_nav = data['in_nav'],
                    in_footer = data['in_footer'],
                    keywords = data['keywords'],
                    description = data['description'],
                    social = data['social'],
                    category = data['category'],
                )
                n_p.save()
                return redirect('posts/1/10')
            else:
                msg = 'Form not cleaned. Page blog.views.py | Line 119'
                return render(request, 'debug.html', {'message': msg})
        else:
            msg = 'Invalid Access. Page blog.views.py | Line 26'
            return render(request, 'debug.html', {'message': msg})
    else:
        msg = 'Not logged in. Page blog.views.py | Line 29'
        return render(request, 'debug.html', {'message': msg})

# It will feed the new nav info into the database
def feed_new_nav(request):
    if is_loggedin(request):
        if request.method == 'POST':
            nav_form = new_nav_form(request.POST)
            if nav_form.is_valid():
                # Extracting Data
                author = User.objects.get(login=request.session['username'])
                category = Category.objects.get(in_nav=1)
                data ={
                    'title': nav_form.cleaned_data['name'],
                    'content': '',
                    'author': author,
                    'pub_date': timezone.now(),
                    'view_count': 0,
                    'url': nav_form.cleaned_data['url'],
                    'unlisted': 0,
                    'last_modified': timezone.now(),
                    'is_page': 0,
                    'in_nav': 1,
                    'in_footer': 0,
                    'keywords': '',
                    'description': '',
                    'social': 0,
                    'category': category, 
                }

                n_n = Post(
                    title = data['title'],
                    content = data['content'],
                    author = data['author'],
                    pub_date = data['pub_date'],
                    view_count = data['view_count'],
                    url = data['url'],
                    unlisted = data['unlisted'],
                    last_modified = data['last_modified'],
                    is_page = data['is_page'],
                    in_nav = data['in_nav'],
                    in_footer = data['in_footer'],
                    keywords = data['keywords'],
                    description = data['description'],
                    social = data['social'],
                    category = data['category'],
                )
                n_n.save()
                return redirect('../navs/')
            else:
                msg = 'Form not cleaned. Page blog.views.py | Line 175'
                return render(request, 'debug.html', {'message': msg})
        else:
            msg = 'Invalid Access. Page blog.views.py | Line 178'
            return render(request, 'debug.html', {'message': msg})
    else:
        msg = 'Not logged in. Page blog.views.py | Line 181'
        return render(request, 'debug.html', {'message': msg})

        

def feed_new_foot(request):
    if is_loggedin(request):
        if request.method == 'POST':
            foot_form = new_foot_form(request.POST)
            if foot_form.is_valid():
                #Extracting Data
                author = User.objects.get(login=request.session['username'])
                category = Category.objects.get(in_footer=1)
                data = {
                    'title': foot_form.cleaned_data['title'],
                    'content': foot_form.cleaned_data['content'],
                    'author': author,
                    'pub_date': timezone.now(),
                    'view_count': 0,
                    'url': foot_form.cleaned_data['url'],
                    'unlisted': 1,
                    'last_modified': timezone.now(),
                    'is_page': 0,
                    'in_nav': 0,
                    'in_footer': 1,
                    'keywords': '',
                    'description': '',
                    'social': 0,
                    'category': category,
                }
                n_f = Post(
                    title = data['title'],
                    content = data['content'],
                    author = data['author'],
                    pub_date = data['pub_date'],
                    view_count = data['view_count'],
                    url = data['url'],
                    unlisted = data['unlisted'],
                    last_modified = data['last_modified'],
                    is_page = data['is_page'],
                    in_nav = data['in_nav'],
                    in_footer = data['in_footer'],
                    keywords = data['keywords'],
                    description = data['description'],
                    social = data['social'],
                    category = data['category'],
                )
                n_f.save()
                return redirect('../foots/')
            else:
                msg = 'Form not cleaned. Page blog.views.py | Line 230'
                return render(request, 'debug.html', {'message': msg})
        else:
            msg = 'Invalid Access. Page blog.views.py | Line 233'
            return render(request, 'debug.html', {'message': msg})
    else:
        msg = 'Not logged in. Page blog.views.py | Line 236'
        return render(request, 'debug.html', {'message': msg})

# -------------- display--------------
# It display the single post
def single_post(request,cat,post_id,post_title):
    single_post = Post.objects.get(pk = post_id)
    return render(request, 'blog/single_post.html', {'single_post': single_post})

