from ckeditor_uploader.fields import RichTextUploadingField
from ckeditor.fields import RichTextField
from ckeditor_uploader.widgets import CKEditorUploadingWidget
from django import forms
from .models import Category

# Form for posting new post
class new_post_form(forms.Form):
    category_list = []
    
    categories = Category.objects.filter(in_nav=0).filter(in_footer=0)
    for record in categories:
        tup = (record.id, record.name)
        category_list.append(tup)

    
    title = forms.CharField(label='Title', max_length=60)

    content = forms.CharField(widget=CKEditorUploadingWidget())

    keywords = forms.CharField(label='Keywords', max_length=60)

    description = forms.CharField(label='Description', max_length=60)

    category = forms.ChoiceField(label='Category', widget=forms.Select, choices=category_list)

# Form for postting new nav link
class new_nav_form(forms.Form):

    name = forms.CharField(label = 'Navlink Name', max_length=10)

    url = forms.URLField(widget=forms.URLInput())

# Form for posting new foot content
class new_foot_form(forms.Form):
    
    title = forms.CharField(label='Heading (Optional)', max_length=20, required=False)

    content = forms.CharField(label='Body', widget=CKEditorUploadingWidget())

    url = forms.URLField(label='Enter Link (Optional)', widget=forms.URLInput(), required=False)